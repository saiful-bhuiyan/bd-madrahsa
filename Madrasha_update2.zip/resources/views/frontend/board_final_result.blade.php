<div class="container border mt-4 p-5 shadow-lg bg-white">
    <div class="row p-2 border rounded">
        <div class="col-lg-12 rounded-3" style="background: #467cf2;">
            <h4 class="text center text-white p-2">Board Final Result</h4>
        </div>
        <div class="col-lg-12 py-4 px-2">
           <h3>Title</h3>
        </div>
        <div class="col-lg-12 ">
            <table class="table">
                <thead>
                    <th>Sl</th>
                    <th>Date</th>
                    <th>Title</th>
                    <th>Download</th>
                </thead>
                <tbody>
                    <tr>
                        <td>title</td>
                        <td>title</td>
                        <td>title</td>
                        <td>title</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>