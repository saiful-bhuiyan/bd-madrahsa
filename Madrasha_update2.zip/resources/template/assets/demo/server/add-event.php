<?php
    // this is our event
    // We need to save it in the database and return it id
    $event = $_POST['event'];

    // but this is a test project so we return a random number as an id
    print rand();
?>