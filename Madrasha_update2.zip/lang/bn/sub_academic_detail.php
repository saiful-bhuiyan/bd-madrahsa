<?php

return array(
    'create_title'=>'একাডেমিক তথ্য',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'title'=>'শিরোনাম',
    'title_en'=>'শিরোনাম ইংরেজি',
    'title_bn'=>'শিরোনাম বাংলা',
    'description'=>'বর্ণনা',
    'description_en'=>'বর্ণনা ইংরেজি',
    'description_bn'=>'বর্ণনা বাংলা',
    'index_title'=> 'সকল একাডেমিক তথ্য',
    'create_message'=>'একাডেমিক তথ্য তৈরি করা হলো',
    'update_message'=>'একাডেমিক তথ্য আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'একাডেমিক তথ্য অপসারণ করা হয়েছে',
    'retrive_message'=>'একাডেমিক তথ্য পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'একাডেমিক তথ্য সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);