<?php

return array(
    'create_title'=>'সাব নাভ ইনফরমেশন',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'title'=>'শিরোনাম',
    'title_en'=>'শিরোনাম ইংরেজি',
    'title_bn'=>'শিরোনাম বাংলা',
    'description'=>'বর্ণনা',
    'description_en'=>'বর্ণনা ইংরেজি',
    'description_bn'=>'বর্ণনা বাংলা',
    'index_title'=> 'সকল নাভ ইনফরমেশন',
    'create_message'=>'নাভ ইনফরমেশন তৈরি করা হলো',
    'update_message'=>'নাভ ইনফরমেশন আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'নাভ ইনফরমেশন অপসারণ করা হয়েছে',
    'retrive_message'=>'নাভ ইনফরমেশন পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'নাভ ইনফরমেশন সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);