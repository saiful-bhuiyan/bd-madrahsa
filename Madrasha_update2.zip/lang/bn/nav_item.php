<?php

return array(
    'create_title'=>'নাভ মেনু',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'nav_name'=>'নাভ নাম',
    'nav_name_en'=>'নাভ ইংরেজি নাম',
    'nav_name_bn'=>'নাভ বাংলা নাম',
    'route_name'=>'রাউটের নাম',
    'index_title'=> 'সকল নাভ',
    'create_message'=>'নাভ তৈরি করা হলো',
    'update_message'=>'নাভ আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'নাভ অপসারণ করা হয়েছে',
    'error_message'=>'নাভ অপসারণ হয়নি ..<br>দয়া করে আগে সাব মেনু ডিলিট করুন',
    'retrive_message'=>'নাভ পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'নাভ সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);