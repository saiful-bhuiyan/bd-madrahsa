<?php

return array(
    'create_title'=>'ব্যানার',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'title'=>'শিরোনাম',
    'title_en'=>'শিরোনাম ইংরেজি',
    'title_bn'=>'শিরোনাম বাংলা',
    'description'=>'বর্ণনা',
    'description_en'=>'বর্ণনা ইংরেজি',
    'description_bn'=>'বর্ণনা বাংলা',
    'index_title'=> 'সকল ব্যানার',
    'create_message'=>'ব্যানার তৈরি করা হলো',
    'update_message'=>'ব্যানার আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'ব্যানার অপসারণ করা হয়েছে',
    'retrive_message'=>'ব্যানার পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'ব্যানার সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);