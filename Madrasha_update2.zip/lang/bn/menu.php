<?php

return array(
    'create_title'=>'মেনু',
    'select_parent'=>'প্রধান মেনু',
    'english_name'=>'ইংরেজি নাম',
    'bangla_name'=>'বাংলা নাম',
    'route_name'=>'রুট',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'type'=>'ধরণ',
    'parent'=>'প্রধান',
    'module'=>'মডিউল',
    'index_title'=>'সকল মেনু',
    'menu_name'=>'মেনুর নাম',
    'menu_name'=>'মেনুর নাম',
    'create_message'=>'মেনু তৈরি করা হলো',
    'update_message'=>'মেনুটি আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'মেনুটি অপসারণ করা হয়েছে',
    'retrive_message'=>'মেনুটি পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'মেনুটি সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);
