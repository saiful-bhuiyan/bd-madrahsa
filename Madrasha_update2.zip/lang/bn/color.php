<?php

return array(
    'create_title'=>'কালার',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'color_name'=>'কালার নাম',
    'color_name_en'=>'কালার ইংরেজি নাম',
    'color_name_bn'=>'কালার বাংলা নাম',
    'index_title'=> 'সকল কালার',
    'create_message'=>'কালার তৈরি করা হলো',
    'update_message'=>'কালার আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'কালার অপসারণ করা হয়েছে',
    'retrive_message'=>'কালার পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'কালার সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);