<?php

return array(
    'create_title'=>'সাব নাভ মেনু',
    'icon'=>'আইকন',
    'order_by'=>'সিরিয়াল',
    'status'=>'স্ট্যাটাস',
    'sub_nav_name'=>'সাব নাভ নাম',
    'sub_nav_name_en'=>'সাব নাভ ইংরেজি নাম',
    'sub_nav_name_bn'=>'সাব নাভ বাংলা নাম',
    'index_title'=> 'সকল সাব নাভ',
    'route_name'=>'রাউটের নাম',
    'create_message'=>'সাব নাভ তৈরি করা হলো',
    'update_message'=>'সাব নাভ আপডেট করা হলো',
    'status_message'=>'স্ট্যাটাস চেন্জ করা হয়েছে',
    'delete_message'=>'সাব নাভ অপসারণ করা হয়েছে',
    'retrive_message'=>'সাব নাভ পুনুরুদ্ধার করা হয়েছে',
    'permenant_delete'=>'সাব নাভ সম্পুর্ণ ভাবে অপসারণ করা হয়েছে',
);