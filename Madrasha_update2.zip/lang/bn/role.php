<?php
return array(
    'create_title'=>'রোল',
    'english_name'=>'ইংরেজি নাম',
    'bangla_name'=>'বাংলা নাম',
    'status'=>'স্ট্যাটাস',
    'index_title'=>'সব রোল',
    'create_message'=>'রোল বানানো হয়েছে',
    'update_message'=>'রোল টি আপডেট করা হয়েছে',
    'status_message'=>'স্ট্যাটাস পরিবর্তন করা হয়েছে',
    'delete_message'=>'রোলটি অপসারণ করা হয়েছে',
    'permission'=>'অনুমতি',
    'role_name'=>'রোল নাম',
    'permission_success'=>'অনুমতি পরিবর্তন করা হয়েছে',
);
