<?php 
return array(
    'headline'=>'বিডি মাদ্রাসা',
    'notice'=>'নোটিস বোর্ড',
);