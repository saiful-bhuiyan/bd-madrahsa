<?php

return array(
    'create_title'=>'Nav Item',
    'select_parent'=>'Select Parent',
    'nav_name'=>'Nav Item Name',
    'nav_name_en'=>'Nav English Name',
    'nav_name_bn'=>'Nav Bangla Name',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Nav Item',
    'route_name'=>'Route Name',
    'create_message'=>'Nav Created Successfully',
    'update_message'=>'Nav Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Nav Is Deleted',
    'error_message'=>'Nav Deleted Failed ..<br>Please Delete child Nav first',
    'retrive_message'=>'Nav Retrive Successfully',
    'permenant_delete'=>'Nav Permenantly Deleted',

);
