<?php

return array(
    'create_title'=>'Board Final Result',
    'select_parent'=>'Select Parent',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'pdf_file'=>'File',
    'status'=>'Status',
    'index_title'=>'All Final Result',
    'create_message'=>'Final Result Created Successfully',
    'update_message'=>'Final Result Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Final Result Is Deleted',
    'retrive_message'=>'Final Result Retrive Successfully',
    'permenant_delete'=>'Final Result Permenantly Deleted',

);
