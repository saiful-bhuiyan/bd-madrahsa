<?php

return array(
    'create_title'=>'Teacher Info',
    'select_parent'=>'Select Parent',
    'headline'=>'Headline',
    'headline_en'=>'Headline English',
    'headline_bn'=>'Headline Bangla',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'description'=>'Description',
    'description_en'=>'Description English',
    'description_bn'=>'Description Bangla',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Teacher Info',
    'create_message'=>'Teacher Info Created Successfully',
    'update_message'=>'Teacher Info Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Teacher Info Is Deleted',
    'retrive_message'=>'Teacher Info Retrive Successfully',
    'permenant_delete'=>'Teacher Info Permenantly Deleted',

);
