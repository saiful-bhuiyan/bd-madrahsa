<?php

return array(
    'create_title'=>'Color',
    'select_parent'=>'Select Parent',
    'color_name'=>'Color Name',
    'color_name_en'=>'Color English Name',
    'color_name_bn'=>'Color Bangla Name',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Color',
    'catagocolor_name'=>'Color Name',
    'create_message'=>'Color Created Successfully',
    'update_message'=>'Color Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Color Is Deleted',
    'retrive_message'=>'Color Retrive Successfully',
    'permenant_delete'=>'Color Permenantly Deleted',

);
