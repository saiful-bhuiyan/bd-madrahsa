<?php

return array(
    'create_title'=>'Banner',
    'select_parent'=>'Select Parent',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'description'=>'Description',
    'description_en'=>'Description English',
    'description_bn'=>'Description Bangla',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Banner',
    'create_message'=>'Banner Created Successfully',
    'update_message'=>'Banner Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Banner Is Deleted',
    'retrive_message'=>'Banner Retrive Successfully',
    'permenant_delete'=>'Banner Permenantly Deleted',

);
