<?php

return array(
    'create_title'=>'Sub Nav Item',
    'select_parent'=>'Select Parent',
    'sub_nav_name'=>'Sub Nav Item Name',
    'sub_nav_name_en'=>'Sub Nav English Name',
    'sub_nav_name_bn'=>'Sub Nav Bangla Name',
    'order_by'=>'Order By',
    'route_name'=>'Route Name',
    'status'=>'Status',
    'index_title'=>'All Nav Item',
    'create_message'=>'Sub Nav Created Successfully',
    'update_message'=>'Sub Nav Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Sub Nav Is Deleted',
    'retrive_message'=>'Sub Nav Retrive Successfully',
    'permenant_delete'=>'Sub Nav Permenantly Deleted',

);
