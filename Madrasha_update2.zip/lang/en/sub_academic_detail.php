<?php

return array(
    'create_title'=>'Sub Academic Details',
    'select_parent'=>'Select Parent',
    'academic_detail_name'=>'Academic Details Name',
    'item_name'=>'Item name',
    'item_name_en'=>'Item English Name',
    'item_name_bn'=>'Item Bangla Name',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'description'=>'Description',
    'description_en'=>'Description English',
    'description_bn'=>'Description Bangla',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Sub Academic Details',
    'create_message'=>'Sub Academic Details Created Successfully',
    'update_message'=>'Sub Academic Details Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Sub Academic Details Is Deleted',
    'retrive_message'=>'Sub Academic Details Retrive Successfully',
    'permenant_delete'=>'Sub Academic Details Permenantly Deleted',

);
