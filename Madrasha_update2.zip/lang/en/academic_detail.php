<?php

return array(
    'create_title'=>'Academic Details',
    'select_parent'=>'Select Parent',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'order_by'=>'Order By',
    'status'=>'Status',
    'index_title'=>'All Academic Details',
    'create_message'=>'Academic Details Created Successfully',
    'update_message'=>'Academic Details Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Academic Details Is Deleted',
    'retrive_message'=>'Academic Details Retrive Successfully',
    'permenant_delete'=>'Academic Details Permenantly Deleted',

);
