<?php

return array(
    'create_title'=>'Sub Nav Information',
    'select_parent'=>'Select Parent',
    'sub_nav_name'=>'Sub Nav Item Name',
    'sub_nav_name_en'=>'Sub Nav English Name',
    'sub_nav_name_bn'=>'Sub Nav Bangla Name',
    'title'=>'Title',
    'title_en'=>'Title English Name',
    'title_bn'=>'Title Bangla Name',
    'description'=>'Description',
    'description_en'=>'Description English',
    'description_bn'=>'Description Bangla',
    'order_by'=>'Order By',
    'route_name'=>'Route Name',
    'status'=>'Status',
    'index_title'=>'All Nav Information',
    'create_message'=>'Nav Information Created Successfully',
    'update_message'=>'Nav Information Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Nav Information Is Deleted',
    'retrive_message'=>'Nav Information Retrive Successfully',
    'permenant_delete'=>'Nav Information Permenantly Deleted',

);
