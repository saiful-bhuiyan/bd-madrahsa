<?php

return array(
    'create_title'=>'Users',
    'user_name'=>'User Name',
    'english_name'=>'English Name',
    'bangla_name'=>'Bangla Name',
    'email'=>'Email',
    'mobile'=>'Mobile',
    'image'=>'Image',
    'password'=>'Password',
    'status'=>'Status',
    'index_title'=>'All User',
    'role'=>'Role',
    'create_message'=>'User Created Successfully',
    'update_message'=>'User Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'User Is Deleted',
    'permission'=>'Permission',
    'role_id'=>'Role ID',
    'name'=>'Name',

);

