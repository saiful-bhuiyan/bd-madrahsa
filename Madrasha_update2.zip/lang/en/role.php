<?php

return array(
    'create_title'=>'Role',
    'english_name'=>'English Name',
    'bangla_name'=>'Bangla Name',
    'status'=>'Status',
    'index_title'=>'All Roles',
    'role_name'=>'Role Name',
    'create_message'=>'Role Created Successfully',
    'update_message'=>'Role Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Role Is Deleted',
    'permission'=>'Permission',
    'permission_success'=>'Permission Update Successfull',

);

