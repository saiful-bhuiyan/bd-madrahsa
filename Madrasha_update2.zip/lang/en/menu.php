<?php

return array(
    'create_title'=>'Menu',
    'select_parent'=>'Select Parent',
    'english_name'=>'English Name',
    'bangla_name'=>'Bangla Name',
    'route_name'=>'Route Name',
    'icon'=>'Icon',
    'order_by'=>'Order By',
    'status'=>'Status',
    'type'=>'Type',
    'parent'=>'Parent',
    'module'=>'Module',
    'create'=>'Create New',
    'index_title'=>'All Menus',
    'menu_name'=>'Menu Name',
    'create_message'=>'Menu Created Successfully',
    'update_message'=>'Menu Is Successfully Updated',
    'status_message'=>'Status Changed',
    'delete_message'=>'Menu Is Deleted',
    'retrive_message'=>'Menu Retrive Successfully',
    'permenant_delete'=>'Menu Permenantly Deleted',

);
