<?php 
return array(
    'headline'=>'BD MADRASHA',
    'notice'=>'Notice Board',
);